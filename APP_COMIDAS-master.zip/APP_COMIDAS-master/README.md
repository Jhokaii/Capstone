Sistema de ventas y Flujo de cajas
